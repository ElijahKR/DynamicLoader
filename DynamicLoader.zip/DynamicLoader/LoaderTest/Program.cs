﻿using DynamicLoader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoaderTest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string subjectDllPath = AppDomain.CurrentDomain.BaseDirectory + "RealSubject.dll";
                LoaderHandler<SubjectProxy> handler = new LoaderHandler<SubjectProxy>(subjectDllPath, "RealSubject.Subject");

                ISubjectBase subject = handler.GetProxy();
                subject.Show("showing...");

                int a = subject.Add(12, 5);
                Console.WriteLine(a.ToString());

                handler.Unload();
            }
            catch (Exception ex)
            {
                Console.WriteLine("error: " + ex.Message);
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
